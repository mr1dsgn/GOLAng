# `/assets`

Other assets to go along with your repository (images, logos, etc).
