# `/web`

Web application specific components: static web assets, server side templates and SPAs.
