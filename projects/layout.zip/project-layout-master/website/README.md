# `/website`

This is the place to put your project's website data if you are not using Github pages.

Examples:

* https://github.com/hashicorp/vault/tree/master/website
* https://github.com/perkeep/perkeep/tree/master/website
