# `/configs`

Configuration file templates or default configs.

Put your `confd` or `consule-template` template files here.
